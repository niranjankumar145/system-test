
package com.test.nbaap;

import static org.testng.Assert.assertEquals;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.apache.xmlbeans.impl.xb.xsdschema.Public;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import atu.testrecorder.exceptions.ATUTestRecorderException;

import com.gargoylesoftware.htmlunit.javascript.host.media.webkitMediaStream;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;
import com.test.base.ErrorUtil;
import com.test.base.baseInfo;
import com.test.nbaap.LogInPage;

public class LogIn extends baseInfo {

	// Getting Main URL of the APP
	@Test
	public void openURL() {

		report = new ExtentReports(System.getProperty("user.dir") + "/test-output/" + "GURU_LoginPage.html", true);
		report.loadConfig(new File(System.getProperty("user.dir") + "//src//test//resources//extent-config.xml"));

		// Get OS name.
		String os = System.getProperty("os.name").toLowerCase();
		logger = report.startTest("Demo Start");
		Assert.assertTrue(true);
		logger.log(LogStatus.INFO, "Browser Started");
		driver.get("http://demo.guru99.com/V4/");
		logger.log(LogStatus.INFO, "Entered Application Url:" + driver.getCurrentUrl());
		String htmlPage = driver.getPageSource();
		String a = "The requested resource is not available.";

		System.out.println();

		if (htmlPage.equals(a)) {
			driver.quit();
			logger.log(LogStatus.ERROR, "Execution Stopped --No data found to start the Execution");
		}
	}

	@Test(dependsOnMethods = "openURL", alwaysRun = true)

	public void browserTitle() throws Exception {
		String expectedTitle = OR.getProperty("browsertitle_LoginPage");
		try {
			System.out.println(expectedTitle + "*********");
			System.out.println(driver.getTitle() + "++++++++++++++");
			Assert.assertEquals(expectedTitle, driver.getTitle());
			Assert.assertTrue(true);
			logger.log(LogStatus.PASS, "Driver Title Matched : " + driver.getTitle());
		} catch (Throwable t) {
			ErrorUtil.addVerificationFailure(t);
			t.printStackTrace();
			logger.log(LogStatus.FAIL, "Title Mis-Matched");
			logger.log(LogStatus.FAIL, "Title Mis-Matched", t);

			capturescreenshot(this.getClass().getSimpleName() + "--Driver Title Error-Login Page");
		}

	}

	@Test(dependsOnMethods = "browserTitle", alwaysRun = true)
	public void topElmnts() {

		List<WebElement> TopelementsList = driver.findElements(By.xpath(OR.getProperty("TopHeaders")));
		for (WebElement Elements : TopelementsList) {
			int i = 0;
			Elements = TopelementsList.get(i);
			System.out.println("elements list is shows in bellow \n ==> " + Elements.getText().toString());
			logger.log(LogStatus.INFO, "Breadcrumb Data:" + Elements.getText().toString()+",");
		}
	}

	@Test(dependsOnMethods = "topElmnts", alwaysRun = true)
	public void homePage() throws IOException {
		try {
			boolean MainPageIMG = driver.findElement(By.xpath(OR.getProperty("MainPageIMG"))).isDisplayed();

			// System.out.println("MainPageIMG => "+ MainPageIMG.getText());

			WebElement mainTitle_Txt_Act = driver.findElement(By.xpath(OR.getProperty("MainTitle_Act")));
			String mainTitle_Txt_Act_STR = mainTitle_Txt_Act.getText();

			System.out.println("MainTitle_Txt =  >> " + mainTitle_Txt_Act_STR);

			String mainTitle_Txt_Exp = OR.getProperty("MainTitle_Exp");

			System.out.println(
					"MainTitle_Txt_Exp =>  " + mainTitle_Txt_Exp + "MainTitle_Txt_Act =>> " + mainTitle_Txt_Act_STR);

			Assert.assertEquals(mainTitle_Txt_Act_STR, mainTitle_Txt_Exp);
			logger.log(LogStatus.PASS, "Home Page Title : " + mainTitle_Txt_Act_STR);
		} catch (Throwable t) {
			ErrorUtil.addVerificationFailure(t);
			t.printStackTrace();
			logger.log(LogStatus.FAIL, "Title Mis-Matched");
			logger.log(LogStatus.FAIL, "Title Mis-Matched", t);

			capturescreenshot(this.getClass().getSimpleName() + "--Header Title Error-Login Page");
		}
	}

	@Test(dependsOnMethods = "homePage", alwaysRun = true)
	public void footerText() throws IOException {
		// TODO Auto-generated method stub
		try {

			WebElement footer_TXT_Act = driver.findElement(By.xpath(OR.getProperty("FooterHeader_Act")));

			String footer_Text = footer_TXT_Act.getText();

			String footer_TXT_Exp = OR.getProperty("FooterHeader_Exo");

			System.out.println("Footer_TXT_Act is = >> " + footer_Text + " === Footer_TXT_Exp => " + footer_TXT_Exp);
			assertEquals(footer_Text, footer_TXT_Exp);

			logger.log(LogStatus.PASS, "Footer Page Title : " + footer_Text);

			List<WebElement> elementsList = driver.findElements(By.xpath(OR.getProperty("BottomListElement")));
			for (WebElement checkBox : elementsList) {
				int i = 0;
				checkBox = elementsList.get(i);
				System.out.println("List elements is ==> " + checkBox.getText().toString());
				logger.log(LogStatus.INFO, "List of Footer Items:" + checkBox.getText().toString()+",");
			}

		} catch (Throwable t) {
			ErrorUtil.addVerificationFailure(t);
			t.printStackTrace();
			logger.log(LogStatus.FAIL, "Footer Header Mis-Matched");
			logger.log(LogStatus.FAIL, "Footer Header Mis-Matched", t);

			capturescreenshot(this.getClass().getSimpleName() + "--Footer Header Title Error-Login Page");
		}
	}

	@Test(dependsOnMethods = "footerText", alwaysRun = true)
	public void loginFunctionality() throws IOException {
		try {
			LogInPage login = new LogInPage();
			login.loginFunctionality();
		} catch (Throwable t) {
			System.out.println("error");
			ErrorUtil.addVerificationFailure(t);
			t.printStackTrace();
			logger.log(LogStatus.FATAL, "Unable to move to Menu");
			capturescreenshot(this.getClass().getSimpleName() + "--SuccessLogIn_Error");
		}
		report.endTest(logger);
		report.flush();
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		driver.close();
		driver.quit();
	}

}
