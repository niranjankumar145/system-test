
package com.test.base;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.rmi.UnexpectedException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.apache.commons.io.FileUtils;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.tools.ant.taskdefs.WaitFor.Unit;
import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import atu.testrecorder.ATUTestRecorder;
import atu.testrecorder.exceptions.ATUTestRecorderException;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
/**
 * @author Niranjan.Kumar
 *
 */
public abstract class baseInfo {
	public static WebDriver driver = null;
	//  public static FirefoxProfile fxProfile=null;
	public static Properties CONFIG = null;
	public static Properties OR = null;
	public static Properties extConfig = null;
	public static Workbook wb = null;
	public static String link = null;
	public static ExtentReports report;
	public static ExtentTest logger;
	public static String pagesource = "";
	public static String fieldSetnoTransformations = "";
	public static String yesTransformations_label = "";
	public static String selvar = "";
	public static String nn = "";
	public static String SelVar = "Dependent";
	public static String Trans = "Logarithmic";
	public static ATUTestRecorder recorder;
	public static String string = "";
	public static String field = "";
	public static String field1 = "";
	public static String fieldSet = "";
	public baseInfo() {
		if (driver == null) {
			// initialize the properties file
			CONFIG = new Properties();
			OR = new Properties();
			try {
				// config
				FileInputStream fs = new FileInputStream(
						System.getProperty("user.dir") + "//src//test//resources//CONFIG.properties");
				CONFIG.load(fs);
				System.out.println("Config File Loaded");
				// OR
				fs = new FileInputStream(System.getProperty("user.dir") + "//src//test//resources//OR.properties");
				OR.load(fs);
				// read data from excel
				FileInputStream readExcel = new FileInputStream(
						System.getProperty("user.dir") + "//src//test//resources//nBAAP.xlsx");
				wb = WorkbookFactory.create(readExcel);
			} catch (Exception e) {
				// error
				return;
			}
			if(CONFIG.getProperty("browser").equals("Mozilla")){
				FirefoxProfile profile = new FirefoxProfile();
				profile.setPreference("network.proxy.type", 0);
				profile.setPreference("browser.download.folderList", 2);
				profile.setPreference("browser.download.manager.showWhenStarting", false);
				profile.setPreference("browser.download.dir", "/home/dev7/Downloads");
				profile.setPreference("browser.helperApps.neverAsk.saveToDisk", "text/csv,application/vnd.ms-excel");
				//profile.setPreference("browser.helperApps.neverAsk.saveToDisk","text/csv");
				profile.setPreference("browser.download.manager.showAlertOnComplete", true);
				profile.setPreference("browser.download.manager.closeWhenDone", true);
				profile.setPreference("browser.download.manager.focusWhenStarting", true);
				DesiredCapabilities dc = new DesiredCapabilities();
				dc.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.DISMISS);
				this.driver = new FirefoxDriver(dc); 
				this.driver.manage().window().maximize();
				this.driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			} else if (CONFIG.getProperty("browser").equals("IE")) {
				DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
				capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,
						true);
				System.setProperty("webdriver.ie.driver",
						System.getProperty("user.dir") + "\\drivers\\IEDriver_2.44\\IEDriverServer.exe");
				this.driver = new InternetExplorerDriver(capabilities);
				this.driver.manage().window().maximize();
				this.driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			} else if (CONFIG.getProperty("browser").equals("Chrome")) {
				//For Windows
			/*	String exePath = "C:\\Users\\username\\Desktop\\chromedriver.exe";
				System.setProperty("webdriver.chrome.driver", exePath);*/
				
				
				System.out.println("chrome 1");
				System.out.println("1111");
				ChromeOptions options = new ChromeOptions();
				options.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.DISMISS);
			  //options.addArguments("--headless");
				options.addArguments("--lang=en");
			  //options.addArguments("--lang=" + locale);
				this.driver = new ChromeDriver(options);
				System.out.println("chrome 2");
				this.driver.manage().window().maximize();
				this.driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				System.out.println("chrome 3");
			}
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		}
	}

	// input
	public void input(String xpathKey, String text) throws IOException {
		try {
			driver.findElement(By.xpath(OR.getProperty(xpathKey))).sendKeys(text);

		} catch (Exception e) {
			e.printStackTrace();
			// capturescreenshot(this.getClass().getSimpleName()+"Defect");
		}
	}

	// click
	public void click(String xpathKey) throws IOException {
		try {
			driver.findElement(By.xpath(OR.getProperty(xpathKey))).click();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// header logo
	public void headerLogo(String xpathKey) throws IOException {
		try {
			String headerlogo = driver.findElement(By.xpath(OR.getProperty(xpathKey))).getText();
		} catch (Throwable t) {
			System.out.println("error");
			ErrorUtil.addVerificationFailure(t);
			t.printStackTrace();
		}
	}

	// screen shot
	public void capturescreenshot(String filename) throws IOException {
		File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(scrFile, new File(System.getProperty("user.dir") + "//screenshots//" + filename + ".png"));
	}

	// selectDropDown
	public void selectDropDown(String xpathkey, String text) {
		try {
			new Select(driver.findElement(By.xpath(OR.getProperty(xpathkey)))).selectByVisibleText(text);
			List<WebElement> allValues = new Select(driver.findElement(By.xpath(OR.getProperty(xpathkey))))
					.getOptions();
			for (WebElement listing : allValues) {
				System.out.println(listing.getText());
				System.out.println(listing.getAttribute("value"));
			}
		} catch (Exception e) {
			System.out.println("error");
			e.printStackTrace();
		}
	}
//Select dropdown with out selection
	
	public void selectDropDownWithOutSelection(String xpathkey) {
		try {
			new Select(driver.findElement(By.xpath(OR.getProperty(xpathkey))));
			List<WebElement> allValues = new Select(driver.findElement(By.xpath(OR.getProperty(xpathkey))))
					.getOptions();
			for (WebElement listing : allValues) {
				System.out.println(listing.getText());
				//System.out.println(listing.getAttribute("value"));
				logger.log(LogStatus.INFO, "Available Variables:"+listing.getText());
			}
		} catch (Exception e) {
			System.out.println("error");
			e.printStackTrace();
		}
	
	Select select = new Select(driver.findElement(By.xpath(OR.getProperty(xpathkey))));
	WebElement option = select.getFirstSelectedOption();
	String defaultItem = option.getText();
	System.out.println("Selected By Default"+defaultItem );
	logger.log(LogStatus.INFO, "Default selected value from the dropdown:"+defaultItem);
	}
	// checkbox for the information value in select variable tab page
	public void checkBox(String path) {
		try {
			driver.findElement(By.id(OR.getProperty(path))).click();
		} catch (Exception e) {
			System.out.println("error");
			e.printStackTrace();

		}
	}

	

	public void testSectionText(String xpathact) throws IOException {
		try {
			Boolean iselementpresent = driver.findElements(By.xpath(OR.getProperty(xpathact))).size() != 0;
			logger.log(LogStatus.PASS, "SectionText Element is Displayed");
		} catch (Throwable t) {
			System.out.println("error");
			ErrorUtil.addVerificationFailure(t);
			logger.log(LogStatus.PASS, "SectionText  is not displayed", t);
			t.printStackTrace();
			capturescreenshot(this.getClass().getSimpleName() + "testSectionText _Error");
		}
	}

	public void getSectionText(String xpathexp, String xpathact) throws IOException {
		try {
			String getMainTitle = OR.getProperty("xpathexp");
			System.out.println("SectionText  of the  Page is : " + getMainTitle);
			logger.log(LogStatus.PASS, "SectionText  of the Page is : "
					+ driver.findElement(By.xpath(OR.getProperty("xpathact"))).getText());

		} catch (Throwable t) {
			t.printStackTrace();
			capturescreenshot(this.getClass().getSimpleName() + "getSectionText_Error");
		}
	}

	public void compareSectionText(String xpathexp, String xpathact) throws IOException {
		try {
			String expectedMainTitle = OR.getProperty(xpathexp);
			String actualMainTitle = "";
			actualMainTitle = driver.findElement(By.xpath(OR.getProperty(xpathact))).getText();
			Assert.assertEquals(expectedMainTitle, actualMainTitle);
			logger.log(LogStatus.PASS, "SectionText is matched : " + actualMainTitle);

		} catch (Throwable t) {
			logger.log(LogStatus.FAIL, "SectionText is not matched");
			logger.log(LogStatus.FAIL, "SectionText is not matched", t);
			capturescreenshot(this.getClass().getSimpleName() + "--SectionText Comparison Failed");
			t.printStackTrace();
		}
	}

	public void testDescText(String xpathact) throws IOException {
		try {
			Boolean iselementpresent = driver.findElements(By.xpath(OR.getProperty(xpathact))).size() != 0;
			logger.log(LogStatus.PASS, "Description Element is Displayed");


		} catch (Throwable t) {
			System.out.println("error");
			ErrorUtil.addVerificationFailure(t);
			logger.log(LogStatus.PASS, "Description Element is not displayed", t);
			t.printStackTrace();
			capturescreenshot(this.getClass().getSimpleName() + "Description_Error");
		}
	}

	public void getDescText(String xpathexp, String xpathact) throws IOException {
		try {
			String getMainTitle = OR.getProperty(xpathexp);
			System.out.println("Description Text of a Page is : " + getMainTitle);
			logger.log(LogStatus.PASS, "Description Text of a Page is : "
					+ driver.findElement(By.xpath(OR.getProperty(xpathact))).getText());

		} catch (Throwable t) {
			t.printStackTrace();
			capturescreenshot(this.getClass().getSimpleName() + "UploadBandTitle_Error");
		}
	}

	public void compareDescText(String xpathexp, String xpathact) throws IOException {
		try {
			String expectedMainTitle = OR.getProperty(xpathexp);
			String actualMainTitle = "";
			actualMainTitle = driver.findElement(By.xpath(OR.getProperty(xpathact))).getText();
			Assert.assertEquals(expectedMainTitle, actualMainTitle);
			logger.log(LogStatus.PASS, "Description Text is matched : " + actualMainTitle);

		} catch (Throwable t) {
			logger.log(LogStatus.FAIL, "Description Text is not matched : ");
			logger.log(LogStatus.FAIL, "Description Text is not matched : ", t);
			capturescreenshot(this.getClass().getSimpleName() + "--Description Text is matched");
			t.printStackTrace();
		}
	}

	
	public void testSave_Btn_Text(String xpathact) throws IOException {
		try {
			Boolean iselementpresent = driver.findElements(By.xpath(OR.getProperty(xpathact))).size() != 0;
			logger.log(LogStatus.PASS, "Save button Text is Displayed");
		} catch (Throwable t) {
			System.out.println("error");
			ErrorUtil.addVerificationFailure(t);
			logger.log(LogStatus.PASS, "Save button Text is not displayed", t);
			t.printStackTrace();
			capturescreenshot(this.getClass().getSimpleName() + "Test_Save button_Option_Text-Error ");
		}
	}

	public void getSave_Btn_Text(String xapthact) throws IOException {
		try {
			String getMainTitle = driver.findElement(By.xpath(OR.getProperty(xapthact))).getText();
			System.out.println(" Text of the  Page is : " + getMainTitle);
			logger.log(LogStatus.PASS, "Save button Text is : "
					+ driver.findElement(By.xpath(OR.getProperty(xapthact))).getText());

		} catch (Throwable t) {
			t.printStackTrace();
			capturescreenshot(this.getClass().getSimpleName() + "GetSave button_Text_Error");
		}
	}

	public void compareSave_Btn_Text(String xpathexp, String xpathact) throws IOException {
		try {
			String expectedMainTitle = OR.getProperty(xpathexp);
			String actualMainTitle = "";
			actualMainTitle = driver.findElement(By.xpath(OR.getProperty(xpathact))).getText();
			Assert.assertEquals(expectedMainTitle, actualMainTitle);
			Assert.assertEquals(expectedMainTitle, actualMainTitle);
			logger.log(LogStatus.PASS, "Save button Text is matched : " + actualMainTitle);

		} catch (Throwable t) {
			logger.log(LogStatus.FAIL, "Save button  Text is not matched");
			logger.log(LogStatus.FAIL, "Save button Text is not  matched", t);
			capturescreenshot(this.getClass().getSimpleName() + "--Save button Text Comparison Failed");
			t.printStackTrace();
		}
	}

	
}
