package com.test.nbaap;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import com.relevantcodes.extentreports.LogStatus;
import com.test.base.baseInfo;

public class LogInPage extends baseInfo {
	public void loginFunctionality() throws IOException, InterruptedException {
		try {
			// UserID
			WebElement userid_value = driver.findElement(By.xpath(OR.getProperty("userID_Xpath")));
			userid_value.sendKeys(OR.getProperty("userID_Value"));
			// Password
			WebElement password_value = driver.findElement(By.xpath(OR.getProperty("password_Xpath")));
			password_value.sendKeys(OR.getProperty("password_Value"));
			// Login button
			WebElement loginButton = driver.findElement(By.xpath(OR.getProperty("loginButton_Xpath")));
			loginButton.click();
			System.out.println("Successfully logged-in ");
			logger.log(LogStatus.INFO, "Entered UserName:" + OR.getProperty("userID_Value"));
			logger.log(LogStatus.INFO, "Entered Password: " + "*********");
			logger.log(LogStatus.PASS, "Succesfully Logged in ");
		}

		catch (Exception e) {
			logger.log(LogStatus.FAIL, "Unable to login");

		}

	}
}
